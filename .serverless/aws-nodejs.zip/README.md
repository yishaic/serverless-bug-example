# serverless-bug-example
Project example demonstrating bug https://github.com/serverless/serverless/issues/1816
